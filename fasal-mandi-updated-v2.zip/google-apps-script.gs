const SHEET_ID = "13ApmZcDFRMc57RF-Zh3EWrFP8AthEGExBiDGfib1RJM";

function doGet() {
  return ContentService
    .createTextOutput("Fasal Mandi Order System is running.");
}

function getOrCreateSheet(name, headers) {
  const ss = SpreadsheetApp.openById(SHEET_ID);
  let sheet = ss.getSheetByName(name);
  if (!sheet) sheet = ss.insertSheet(name);
  if (sheet.getLastRow() === 0) sheet.appendRow(headers);
  return sheet;
}

function doPost(e) {
  try {
    let data = {};
    if (e.postData && e.postData.contents) {
      try { data = JSON.parse(e.postData.contents); }
      catch (err) { data = e.parameter || {}; }
    } else {
      data = e.parameter || {};
    }

    const type = String(data.orderType || "SELL").toUpperCase();

    if (type === "BUY") {
      const sheet = getOrCreateSheet("Buy Orders", [
        "Order ID","Date","Customer Name","Phone","Address",
        "Payment Method","Items","Total","Status"
      ]);

      const items = Array.isArray(data.items)
        ? data.items.map(x => `${x.name} × ${x.quantity}`).join(" | ")
        : String(data.items || "");

      sheet.appendRow([
        data.orderId || "",
        new Date(),
        data.customerName || "",
        data.phone || "",
        data.address || "",
        data.paymentMethod || "",
        items,
        data.total || "",
        "Pending"
      ]);
    } else {
      const sheet = getOrCreateSheet("Sell Orders", [
        "Order ID","Date","Farmer Name","Phone","Village / Address",
        "Product","Variety","Quantity","Unit","Stock Status",
        "Expected Price","Notes","Pickup Date","Landmark","Status"
      ]);

      sheet.appendRow([
        data.orderId || "",
        new Date(),
        data.farmerName || data.name || "",
        data.phone || "",
        data.village || data.address || "",
        data.product || "",
        data.variety || "",
        data.quantity || "",
        data.unit || "",
        data.stockStatus || "",
        data.expectedPrice || "",
        data.grainNotes || "",
        data.pickupDate || "",
        data.landmark || "",
        "Pending"
      ]);
    }

    return ContentService
      .createTextOutput(JSON.stringify({success:true}))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (error) {
    return ContentService
      .createTextOutput(JSON.stringify({success:false,error:String(error)}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
