/**
 * FASAL MANDI — Google Sheets order receiver
 *
 * SETUP:
 * 1. Create a Google Sheet using the Gmail account that should receive orders.
 * 2. Extensions → Apps Script.
 * 3. Replace the default code with this file and Save.
 * 4. Deploy → New deployment → Web app.
 * 5. Execute as: Me
 * 6. Who has access: Anyone
 * 7. Copy the Web app URL and paste it into
 *    GOOGLE_SHEET_WEB_APP_URL in fasal-mandi-google-sheet.html.
 *
 * A sheet named "Sell Requests" will be created automatically.
 */

const SHEET_NAME = 'Sell Requests';

function doGet() {
  return ContentService
    .createTextOutput('Fasal Mandi order receiver is running.')
    .setMimeType(ContentService.MimeType.TEXT);
}

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents || '{}');
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = ss.getSheetByName(SHEET_NAME);

    if (!sheet) {
      sheet = ss.insertSheet(SHEET_NAME);
      sheet.appendRow([
        'Order ID',
        'Submitted At',
        'Farmer Name',
        'Phone',
        'Village / Area',
        'Product',
        'Variety',
        'Quantity',
        'Unit',
        'Stock Status',
        'Expected Price / Quintal',
        'Pickup Date',
        'Landmark',
        'Notes',
        'Status'
      ]);
      sheet.setFrozenRows(1);
    }

    sheet.appendRow([
      data.orderId || '',
      data.submittedAt ? new Date(data.submittedAt) : new Date(),
      data.farmerName || '',
      data.phone || '',
      data.village || '',
      data.product || '',
      data.variety || '',
      data.quantity || '',
      data.unit || '',
      data.stockStatus || '',
      data.expectedPrice || '',
      data.pickupDate || '',
      data.landmark || '',
      data.grainNotes || '',
      'Pending'
    ]);

    return ContentService
      .createTextOutput(JSON.stringify({ok:true, orderId:data.orderId || ''}))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ok:false, error:String(err)}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
